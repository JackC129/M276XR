//@input Component.Text textComponentToChange
//@input string targetDate = "2025-03-01"

var daysUntilDate = global.calculateRemainingDays(script.targetDate)

var message = " Days left!"

if (daysUntilDate == 1) {
    message = " Day left!"
}
else if (daysUntilDate <= 0) {
    script.textComponentToChange.enabled = false
}
script.textComponentToChange.text = daysUntilDate + message
