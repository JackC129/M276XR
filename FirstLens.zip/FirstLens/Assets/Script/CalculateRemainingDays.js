global.calculateRemainingDays = function(targetDate) {
    var currentDate = new Date();
    var target = new Date(targetDate);
    var timeDifference = target - currentDate;
    var daysRemaining = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));
    return daysRemaining;
}
