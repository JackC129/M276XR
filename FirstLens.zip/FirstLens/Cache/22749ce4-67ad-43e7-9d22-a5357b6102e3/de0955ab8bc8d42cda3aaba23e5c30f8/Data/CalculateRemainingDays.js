//@input string targetDate // Format: "YYYY-MM-DD"

global.calculateRemainingDays(targetDate) {
    var currentDate = new Date();
    var target = new Date(targetDate);
    var timeDifference = target - currentDate;
    var daysRemaining = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));
    return daysRemaining;
}

var daysLeft = calculateRemainingDays(script.targetDate);
print("Days remaining: " + daysLeft);
