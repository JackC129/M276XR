//@input Component.Text textComponentToChange
//@input string newText

var variable_example