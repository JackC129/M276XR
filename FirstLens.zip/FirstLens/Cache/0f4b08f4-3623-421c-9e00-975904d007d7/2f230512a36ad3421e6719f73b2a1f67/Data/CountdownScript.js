//@input Component.Text textComponentToChange
//@input string newText

var variable = 10

print(variable)       // This outputs 10 to the logger panel
print(script.newText) // This outputs the string we set in the Inspector to the logger panel

script.textComponentToChange.text = script.newText
