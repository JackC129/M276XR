//@input Component.Text textComponentToChange
//@input string targetDate = "2025-03-01"

var daysUntilDate = global.calculateRemainingDays(script.targetDate)
script.textComponentToChange.text = daysUntilDate + " Days left!"
