"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Point = void 0;
const Config_1 = require("../../Shared/Config");
const SharedContent_1 = require("../../Shared/SharedContent");
const TouchControl_1 = require("../TouchControl");
const SidePoint_1 = require("../Selection/SidePoint");
const SelectedRect_1 = require("../Selection/SelectedRect");
const Data_1 = require("../../Shared/Data");
var iState;
(function (iState) {
    iState[iState["Active"] = 0] = "Active";
    iState[iState["Hover"] = 1] = "Hover";
    iState[iState["Selected"] = 2] = "Selected";
    iState[iState["Default"] = 3] = "Default";
})(iState || (iState = {}));
class Point {
    constructor(sceneObject, id, onUpdate) {
        this.isActive = false;
        this.selected = false;
        this._initialPosition = null;
        this._currentPosition = null;
        this.offset = vec2.zero();
        this.sceneObject = sceneObject;
        this.sceneObject.enabled = true;
        this.screenTransform = this.sceneObject.getComponent("Component.ScreenTransform");
        this.image = this.sceneObject.getComponent("Component.Image");
        this.initScale = this.screenTransform.scale;
        this.id = id;
        this.onUpdate = onUpdate;
        this.initButton();
    }
    get symmetricalPoint() { return this._symmetricalPoint; }
    set position(newPosition) {
        this._currentPosition = newPosition;
        if (!this._initialPosition) {
            this._initialPosition = newPosition;
        }
        this.screenTransform.anchors.setCenter(newPosition);
    }
    get position() {
        return this._currentPosition;
    }
    get worldPosition() {
        return this.screenTransform.localPointToWorldPoint(vec2.zero());
    }
    get screenPosition() {
        return this.screenTransform.localPointToScreenPoint(vec2.zero());
    }
    set screenPosition(pos) {
        this.position = this.screenTransform.screenPointToParentPoint(pos);
    }
    get isLocked() {
        return this.isActive;
    }
    get initialPosition() {
        return this._initialPosition;
    }
    get delta() {
        return this.position.sub(this._initialPosition);
    }
    set delta(delta) {
        this.position = this._initialPosition.add(delta);
    }
    setScale(newScale) {
        const val = this.initScale.uniformScale(newScale);
        val.z = this.initScale.z;
        this.screenTransform.scale = val;
    }
    addScreenDelta(delta, syncWithSymmetricPoint = false) {
        const localDelta = this.screenTransform.screenPointToParentPoint(this.screenPosition.add(delta)).sub(this.position);
        this.addDelta(localDelta, syncWithSymmetricPoint);
    }
    addDelta(delta, syncWithSymmetricPoint = false) {
        const tmpX = delta.x;
        if (syncWithSymmetricPoint && Config_1.Config.isSymmetrical) {
            const symmetrical = this._symmetricalPoint;
            if (symmetrical) {
                if (!symmetrical.isSelected) {
                    delta.x *= -1;
                    symmetrical.addDelta(delta);
                    delta.x = tmpX;
                }
            }
            else {
                // lock horizontal movement for points without symmetry in symmetrical mode
                delta.x = 0;
            }
        }
        this.position = this._currentPosition.add(delta);
        delta.x = tmpX;
    }
    setSymmetricalPoint(point) {
        if (!point || point.id == this.id) {
            this._symmetricalPoint = null;
        }
        else {
            // This is to prevent pseudo-symmetry on points that have 
            // symmetry point overlapping them but hidden, otherwise
            // we can't lock them as self-symmetric when symmetry is required.
            // todo: probably should treat it as a sidecar, not a symmetry.
            const hiddenSymmetry = Data_1.Constants.CANDIDE_OVERLAPING_POINTS_TO_HIDE.indexOf(point.id) >= 0;
            this._symmetricalPoint = hiddenSymmetry ? null : point;
        }
    }
    setLocked(value, syncWithSymmetricPoint = false) {
        var _a;
        this.isActive = value;
        this.image.mainPass.iState = this.iState;
        if (syncWithSymmetricPoint && Config_1.Config.isSymmetrical) {
            (_a = this._symmetricalPoint) === null || _a === void 0 ? void 0 : _a.setLocked(value);
        }
    }
    breakKey() {
        this.setLocked = (value) => {
            if (this.isActive != value) {
                //@ts-ignore
                Editor.print("This point can't be " + (value ? "activated" : "decativated"));
            }
        };
    }
    isEnabled() {
        return this.sceneObject.enabled;
    }
    hide() {
        this.sceneObject.enabled = false;
    }
    show() {
        this.sceneObject.enabled = true;
    }
    containsScreenPoint(pos) {
        return this.screenTransform.containsScreenPoint(pos);
    }
    setSelected(value) {
        this.selected = value;
        this.image.mainPass.iState = this.iState;
    }
    get isSelected() {
        return this.selected;
    }
    get iState() {
        return this.isActive
            ? this.isSelected ? iState.Selected : iState.Active
            : iState.Default;
    }
    update() {
        this.onUpdate();
    }
    initButton() {
        const onStartCallback = (position) => {
            var _a;
            if (SidePoint_1.SidePoint.isBusy || SelectedRect_1.SelectedRect.isBusy) {
                return;
            }
            // point is round, skip clicks on corners
            if (this.screenTransform.screenPointToLocalPoint(position).length > 1) {
                this.offset = null;
                return;
            }
            this.offset = this.position
                .sub(this.screenTransform.screenPointToParentPoint(position));
            this.setLocked(true, true);
            (_a = Point.lastClickSelected) === null || _a === void 0 ? void 0 : _a.setSelected(false);
            this.setSelected(true);
            Point.lastClickSelected = this;
            this.update();
        };
        const onMoveCallback = (position) => {
            if (SidePoint_1.SidePoint.isBusy || SelectedRect_1.SelectedRect.isBusy || !this.offset) {
                return;
            }
            const newPosition = this.screenTransform.screenPointToParentPoint(position)
                .add(this.offset);
            this.addDelta(newPosition.sub(this.position), true);
            this.update();
        };
        const onDoubleTapCallback = () => {
            this.setLocked(false, true);
            this.update();
        };
        this.button = new TouchControl_1.TouchControl(this.sceneObject, SharedContent_1.SharedContent.getInstance().orthoCamera, onStartCallback, onMoveCallback, onDoubleTapCallback);
        this.sceneObject.enabled = true;
        this._initialPosition = this.position;
    }
}
exports.Point = Point;
//# sourceMappingURL=Point.js.map