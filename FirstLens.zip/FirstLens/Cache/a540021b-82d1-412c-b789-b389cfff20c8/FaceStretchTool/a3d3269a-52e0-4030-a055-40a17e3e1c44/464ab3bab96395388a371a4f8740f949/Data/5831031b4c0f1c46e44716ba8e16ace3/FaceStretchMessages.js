"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExportData = exports.ImportData = exports.FeatureNameMessage = exports.ResetButtonMessage = exports.RightArrowButtonMessage = exports.LeftArrowButtonMessage = exports.ResetPointsButtonMessage = exports.ExportButtonMessage = exports.ImportButtonMessage = exports.AddButtonMessage = exports.SymmetricModeButtonMessage = void 0;
const BaseMessage_1 = require("./BaseMessage");
class SymmetricModeButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.SymmetricModeButtonMessage = SymmetricModeButtonMessage;
class AddButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.AddButtonMessage = AddButtonMessage;
class ImportButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.ImportButtonMessage = ImportButtonMessage;
class ExportButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.ExportButtonMessage = ExportButtonMessage;
class ResetPointsButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.ResetPointsButtonMessage = ResetPointsButtonMessage;
class LeftArrowButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.LeftArrowButtonMessage = LeftArrowButtonMessage;
class RightArrowButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.RightArrowButtonMessage = RightArrowButtonMessage;
class ResetButtonMessage extends BaseMessage_1.BaseMessage {
}
exports.ResetButtonMessage = ResetButtonMessage;
class FeatureNameMessage extends BaseMessage_1.BaseMessage {
    constructor() {
        super(...arguments);
        this.name = "";
    }
}
exports.FeatureNameMessage = FeatureNameMessage;
class ImportData extends BaseMessage_1.BaseMessage {
    constructor() {
        super(...arguments);
        this.data = "";
    }
}
exports.ImportData = ImportData;
class ExportData extends BaseMessage_1.BaseMessage {
    constructor() {
        super(...arguments);
        this.data = "";
    }
}
exports.ExportData = ExportData;
//# sourceMappingURL=FaceStretchMessages.js.map