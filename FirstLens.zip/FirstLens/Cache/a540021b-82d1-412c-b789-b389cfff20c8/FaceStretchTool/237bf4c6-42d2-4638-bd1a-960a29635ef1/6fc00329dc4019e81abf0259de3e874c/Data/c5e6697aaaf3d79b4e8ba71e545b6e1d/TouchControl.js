"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TouchControl = void 0;
const SelectionControl_1 = require("./Selection/SelectionControl");
const SelectedRect_1 = require("./Selection/SelectedRect");
const LensRegion_1 = require("../Common/Utilities/LensRegion/LensRegion");
class TouchControl {
    constructor(so, cam, onStartCallback, onMoveCallback, onDoubleTapCallback) {
        this.lastPosition = null;
        this.doubleTapMaxDelay = 0.5;
        this.doubleTapMaxDistance = 0.01;
        this.lastTapTime = -1;
        this.so = so;
        this.cam = cam;
        this.onMoveCallback = onMoveCallback;
        this.onDoubleTapCallback = onDoubleTapCallback;
        this.onStartCallback = onStartCallback;
        this.createTouchComponentOnSceneObject();
        this.createScriptComponentWithEvents();
    }
    createTouchComponentOnSceneObject() {
        if (this.so.getComponents("Component.Image").length > 0) {
            this.image = this.so.getComponent("Component.Image");
        }
        const touchComponent = this.so.createComponent("Component.TouchComponent");
        touchComponent.setCamera(this.cam);
        touchComponent.addMeshVisual(this.image);
    }
    createScriptComponentWithEvents() {
        const scriptComponent = this.so.createComponent("Component.ScriptComponent");
        const touchStart = scriptComponent.createEvent("TouchStartEvent");
        touchStart.bind((eventData) => {
            if (TouchControl.isBusy || SelectionControl_1.SelectionControl.isBusy || SelectedRect_1.SelectedRect.isBusy || LensRegion_1.LensRegion.isBusy) {
                this.propagateMove(eventData.getTouchPosition());
                return;
            }
            TouchControl.isBusy = true;
            TouchControl._activeControl = this;
            this.lastPosition = eventData.getTouchPosition();
            this.onStartCallback(eventData.getTouchPosition());
        });
        const onMove = (eventData) => {
            if (this.lastPosition) {
                const pos = eventData.getTouchPosition();
                this.onMoveCallback(pos);
                this.lastPosition = pos;
            }
            else {
                this.propagateMove(eventData.getTouchPosition());
            }
        };
        const touchMove = scriptComponent.createEvent("TouchMoveEvent");
        touchMove.bind(onMove);
        const touchEnd = scriptComponent.createEvent("TouchEndEvent");
        touchEnd.bind((eventData) => {
            if (this.lastPosition) {
                onMove(eventData);
                this.lastPosition = null;
                TouchControl.isBusy = false;
                TouchControl._activeControl = null;
            }
            else {
                this.propagateMove(eventData.getTouchPosition());
            }
        });
        const tapEvent = scriptComponent.createEvent("TapEvent");
        tapEvent.bind((eventData) => {
            const currentTime = getTime();
            const pos = eventData.getTapPosition();
            const dT = currentTime - this.lastTapTime;
            if (dT < this.doubleTapMaxDelay && this.lastPosition && pos.distance(this.lastPosition) < this.doubleTapMaxDistance) {
                this.onDoubleTapCallback(pos);
                this.lastTapTime = -1;
            }
            else {
                this.lastTapTime = currentTime;
            }
            this.lastPosition = pos;
        });
        const doubleTapEvent = scriptComponent.createEvent("DoubleTapEvent");
        doubleTapEvent.bind((eventData) => {
            this.onDoubleTapCallback(eventData.getTapPosition());
        });
    }
    // Can't use InteractionComponent.isFilteredByDepth = false, because it will emmit touch end when moving out of
    // object bounds without regard that we moved object to keep it in bounds (probably a bug?).
    // So, this hack redirects event to the currently selected control instead.
    propagateMove(pos) {
        var _a;
        if (TouchControl.isBusy && TouchControl._activeControl != this) {
            (_a = TouchControl._activeControl) === null || _a === void 0 ? void 0 : _a.onMoveCallback(pos);
        }
    }
}
exports.TouchControl = TouchControl;
TouchControl.isBusy = false;
//# sourceMappingURL=TouchControl.js.map