"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CandideProvider = void 0;
class CandideProvider {
    constructor(script, maxFaceTracked) {
        this.events = [];
        this.callbacks = [];
        for (let i = 0; i < maxFaceTracked; ++i) {
            const newEvent = script.createEvent("CandideUpdatedEvent");
            this.events.push(newEvent);
            newEvent.faceIndex = i;
            this.callbacks.push([]);
            newEvent.bind((eventData) => {
                const idx = eventData.faceIndex;
                this.callbacks[idx].forEach((cb) => {
                    cb(eventData.points2d, eventData.faceIndex);
                });
            });
        }
    }
    addCallbackForFace(index, cb) {
        this.callbacks[index].push(cb);
    }
    callOnceForFace(index, cb) {
        this.callbacks[index].push((data) => {
            // print("RETURN CANDIDE DATA YAY!");
            cb && cb(data);
            cb = null;
        });
    }
}
exports.CandideProvider = CandideProvider;
//# sourceMappingURL=CandideProvider.js.map