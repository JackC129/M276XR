"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FeaturesControl = void 0;
var __selfType = requireType("./FeaturesControl");
function component(target) { target.getTypeName = function () { return __selfType; }; }
const Data_1 = require("../Shared/Data");
const UndoListener_1 = require("./UndoListener");
const EffectEditor_1 = require("./EffectEditor");
const FaceStretchMessages_1 = require("./MessageCenter/MessageTypes/FaceStretchMessages");
let FeaturesControl = class FeaturesControl extends BaseScriptComponent {
    onAwake() {
        UndoListener_1.UndoListener.getInstance(this).setFeaturesControl(this);
        if (!isNull(EffectEditor_1.EffectEditor.faceStretchComponent)) {
            this.load();
        }
    }
    load() {
        if (this.isLoaded) {
            return;
        }
        log("Load");
        this.isLoaded = true;
        this.copyFeaturesFromProxy();
        this.updateDisplayName();
        this.pointsEditor.load();
        this.activeFeatureIdx = 0;
        log("Loaded");
    }
    get activeFeatureIdx() {
        return this._activeFeatureIdx;
    }
    set activeFeatureIdx(value) {
        this.load();
        this._activeFeatureIdx = value;
        this.pointsEditor.setActiveFeature(this._activeFeatureIdx);
        this.updateDisplayName();
        log("Active feature set to " + value);
    }
    updateDisplayName() {
        var _a;
        const curName = this._activeFeatureIdx < 0 ? "" : (_a = this.faceStretch.getFeatureNames()[this._activeFeatureIdx]) !== null && _a !== void 0 ? _a : "";
        //@ts-ignore
        Editor.context.postMessage(FaceStretchMessages_1.FeatureNameMessage.create({
            name: curName
        }));
        // this.pickedFeatureName.text = this._activeFeatureIdx < 0 ? "" : this.faceStretch.getFeatureNames()[this._activeFeatureIdx] ?? "";
    }
    addNewFeature() {
        const featureName = this.getNewName();
        this.faceStretch.addFeature(featureName);
        this.visualStretch.addFeature(featureName);
        EffectEditor_1.EffectEditor.faceStretchComponent.addFeature(featureName);
        this.resetFeature(featureName);
        this.activeFeatureIdx = this.visualStretch.getFeatureNames().length - 1;
        this.pointsEditor.update();
        this.load();
    }
    forgetFeature(name) {
        const names = this.faceStretch.getFeatureNames();
        const idx = names.indexOf(name);
        if (idx >= 0) {
            this.faceStretch.removeFeature(name);
            this.visualStretch.removeFeature(name);
            if (idx < this.activeFeatureIdx || (idx == this.activeFeatureIdx && idx == names.length - 1)) {
                // lost feature below (need to offset index to keep the same name)
                // or lost the last one which was active (need to update index so we point to last)
                this.activeFeatureIdx--;
            }
            this.updateDisplayName(); // could change within same index
            log("Feature " + name + " is no longer with us");
        }
    }
    copyFeaturesFromProxy() {
        log("Load features from proxy");
        EffectEditor_1.EffectEditor.copyFeaturesTo(EffectEditor_1.EffectEditor.faceStretchComponent, this.faceStretch);
        EffectEditor_1.EffectEditor.copyFeaturesTo(EffectEditor_1.EffectEditor.faceStretchComponent, this.visualStretch);
    }
    copyFeatureFromProxy(name, create) {
        log("Copy feature " + name + (create ? " (create)" : " (update)") + " from proxy");
        if (create) {
            this.faceStretch.addFeature(name);
            this.visualStretch.addFeature(name);
            this.resetFeature(name);
        }
        EffectEditor_1.EffectEditor.setFeaturePointsTo(EffectEditor_1.EffectEditor.faceStretchComponent, this.faceStretch, name);
        EffectEditor_1.EffectEditor.setFeaturePointsTo(EffectEditor_1.EffectEditor.faceStretchComponent, this.visualStretch, name);
    }
    resetFeature(name) {
        var _a;
        const points = this.faceStretch.getFeaturePoints(name);
        points.forEach((point, idx) => {
            point.weight = 3 * +Data_1.Constants.CANDIDE_POINTS[idx][1];
        });
        this.faceStretch.updateFeaturePoints(name, points);
        this.visualStretch.updateFeaturePoints(name, points);
        EffectEditor_1.EffectEditor.updateFeaturePoints(name, points);
        this.faceStretch.setFeatureWeight(name, 1);
        this.visualStretch.setFeatureWeight(name, 1);
        (_a = EffectEditor_1.EffectEditor.faceStretchComponent) === null || _a === void 0 ? void 0 : _a.setFeatureWeight(name, 1);
    }
    getNewName() {
        let found;
        let name;
        let names = EffectEditor_1.EffectEditor.faceStretchComponent.getFeatureNames();
        let featuresNameCount = 0;
        do {
            found = true;
            name = "Feature " + featuresNameCount;
            names.forEach((fName) => {
                if (fName === name) {
                    found = false;
                }
            });
            featuresNameCount++;
        } while (!found);
        return name;
    }
    next() {
        this.activeFeatureIdx = (this.activeFeatureIdx + 1) % this.faceStretch.getFeatureNames().length;
    }
    prev() {
        this._activeFeatureIdx = this._activeFeatureIdx - 1;
        if (this._activeFeatureIdx < 0) {
            this._activeFeatureIdx = this.faceStretch.getFeatureNames().length - 1;
        }
        this.activeFeatureIdx = this._activeFeatureIdx;
    }
    onLeftArrowClicked() {
        this.prev();
    }
    onRightArrowClicked() {
        this.next();
    }
    setButtonsState(state) {
        // this.nextButtonObj.enabled = state;
        // this.prevButtonObj.enabled = state;
    }
    __initialize() {
        super.__initialize();
        this._activeFeatureIdx = 0;
        this.isLoaded = false;
    }
};
exports.FeaturesControl = FeaturesControl;
exports.FeaturesControl = FeaturesControl = __decorate([
    component
], FeaturesControl);
function log(text) {
    return;
    text = "[FC]: " + text;
    //@ts-ignore
    if (typeof Editor !== "undefined") {
        //@ts-ignore
        Editor.print(text);
    }
    else {
        print(text);
    }
}
//# sourceMappingURL=FeaturesControl.js.map