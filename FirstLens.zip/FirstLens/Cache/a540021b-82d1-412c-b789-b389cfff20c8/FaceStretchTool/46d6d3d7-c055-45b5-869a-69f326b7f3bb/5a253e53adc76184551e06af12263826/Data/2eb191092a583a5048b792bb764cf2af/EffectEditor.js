"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var EffectEditor_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EffectEditor = void 0;
var __selfType = requireType("./EffectEditor");
function component(target) { target.getTypeName = function () { return __selfType; }; }
const SelectionListener_1 = require("./SelectionListener");
let EffectEditor = EffectEditor_1 = class EffectEditor extends BaseScriptComponent {
    onAwake() {
        this.setupSelectionListener();
        this.faceStretch.clearFeatures();
        this.visualStretch.clearFeatures();
        this.createEvent("UpdateEvent").bind(() => {
            this.listenForChanges();
        });
        this.listenForChanges();
        if (!this.trySetFaceStretch()) {
            return;
        }
    }
    setupSelectionListener() {
        this.selectionListener = new SelectionListener_1.SelectionListener(this);
        this.selectionListener.setOnSelectionUpdate(() => {
            this.update();
        });
    }
    update() {
        this.selectedObject = this.selectionListener.getSelectedObject();
        this.needUpdateFeatureIdx = true;
    }
    listenForChanges() {
        var _a;
        if (isNull(this.selectedObject)) {
            this.editorObject.enabled = false;
            this.defaultTextObject.enabled = true;
            if (this.featuresControl.setButtonsState) {
                this.featuresControl.setButtonsState(false);
            }
            return;
        }
        //@ts-ignore
        let faceStretchComponents = this.selectedObject.getComponents("FaceStretchVisual");
        if (faceStretchComponents.length != 1) {
            this.editorObject.enabled = false;
            this.defaultTextObject.enabled = true;
            if (this.featuresControl.setButtonsState) {
                this.featuresControl.setButtonsState(false);
            }
            EffectEditor_1.faceStretchComponent = null;
            return;
        }
        EffectEditor_1.faceStretchComponent = faceStretchComponents[0];
        if (this.needUpdateFeatureIdx) {
            this.needUpdateFeatureIdx = false;
            if ((_a = this.featuresControl) === null || _a === void 0 ? void 0 : _a.copyFeaturesFromProxy) {
                this.featuresControl.copyFeaturesFromProxy();
                this.featuresControl.activeFeatureIdx = 0;
                this.pointsEditor.update();
            }
        }
        this.defaultTextObject.enabled = false;
        if (this.featuresControl.setButtonsState) {
            this.featuresControl.setButtonsState(true);
        }
        this.editorObject.enabled = true;
    }
    //@ts-ignore
    getFirstFaceStretch() {
        var _a;
        //@ts-ignore
        let faceStretchComp = (_a = this.selectedObject) === null || _a === void 0 ? void 0 : _a.getComponent("FaceStretchVisual");
        return faceStretchComp;
    }
    trySetFaceStretch() {
        //@ts-ignore
        const faceStretchComp = this.getFirstFaceStretch();
        if (faceStretchComp) {
            this.copyFeaturesFromTo(faceStretchComp, this.faceStretch);
            this.copyFeaturesFromTo(faceStretchComp, this.visualStretch);
            return true;
        }
        return false;
    }
    //@ts-ignore
    copyFeaturesFromTo(from, to) {
        const names = from.getFeatureNames();
        names.forEach((name) => {
            to.addFeature(name);
            EffectEditor_1.updateFeaturePoints(name, from.getFeaturePoints(name), to);
            to.setFeatureWeight(name, from.getFeatureWeight(name));
        });
    }
    static updateFeaturePoints(name, newPoints, 
    //@ts-ignore
    faceStretch = null) {
        faceStretch = faceStretch !== null && faceStretch !== void 0 ? faceStretch : EffectEditor_1.faceStretchComponent;
        if (!faceStretch) {
            return;
        }
        if (faceStretch.getFeatureNames().indexOf(name) == -1) {
            return;
        }
        const points = faceStretch.getFeaturePoints(name);
        points.forEach((point, idx) => {
            point.weight = newPoints[idx].weight;
            point.delta = newPoints[idx].delta;
        });
        faceStretch.updateFeaturePoints(name, points);
    }
    //@ts-ignore
    static setFeaturePointsTo(inner, faceStretch, name) {
        this.updateFeaturePoints(name, inner.getFeaturePoints(name), faceStretch);
    }
    //@ts-ignore
    static copyFeaturesTo(inner, faceStretch) {
        faceStretch.clearFeatures();
        inner.getFeatureNames().forEach((name) => {
            faceStretch.addFeature(name);
            EffectEditor_1.setFeaturePointsTo(inner, faceStretch, name);
            faceStretch.setFeatureWeight(name, inner.getFeatureWeight(name));
        });
    }
    __initialize() {
        super.__initialize();
        this.needUpdateFeatureIdx = false;
    }
};
exports.EffectEditor = EffectEditor;
exports.EffectEditor = EffectEditor = EffectEditor_1 = __decorate([
    component
], EffectEditor);
//# sourceMappingURL=EffectEditor.js.map