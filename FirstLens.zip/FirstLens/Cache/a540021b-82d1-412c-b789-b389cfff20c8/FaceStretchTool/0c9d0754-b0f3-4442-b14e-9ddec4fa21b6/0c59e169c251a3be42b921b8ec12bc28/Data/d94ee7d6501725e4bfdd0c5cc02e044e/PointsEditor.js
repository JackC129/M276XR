"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PointsEditor = void 0;
var __selfType = requireType("./PointsEditor");
function component(target) { target.getTypeName = function () { return __selfType; }; }
const Point_1 = require("./Base/Point");
const CandideProvider_1 = require("./CandideProvider");
const Data_1 = require("../Shared/Data");
const Line_1 = require("./Base/Line");
const LineRenderer_1 = require("./LineRenderer");
const UndoListener_1 = require("./UndoListener");
const EffectEditor_1 = require("./EffectEditor");
const FaceStretchMessages_1 = require("./MessageCenter/MessageTypes/FaceStretchMessages");
const MessageCenter_1 = require("./MessageCenter/MessageCenter");
let PointsEditor = class PointsEditor extends BaseScriptComponent {
    onAwake() {
        this.lateUpdateEvent = this.createEvent("LateUpdateEvent");
        this.main.addPinchOnUpdateCallback(() => {
            this.updatePointsScale();
        });
        this.selectionControl.start(this.points, this.update.bind(this));
        MessageCenter_1.MessageCenter.instance.subscribe(FaceStretchMessages_1.ImportData, (message) => {
            this.processImportData(message.data);
        });
    }
    load() {
        if (this.isLoaded) {
            return;
        }
        log("Load");
        this.activeFeatureName = this.faceStretch.getFeatureNames()[this.activeFeatureIndex];
        this.root = this.referencePoint.getParent();
        if (!this.candideProvider)
            this.candideProvider = new CandideProvider_1.CandideProvider(this, 1);
        this.candideProvider.callOnceForFace(0, (points) => {
            log("Setup face...");
            this.setupCandidePoints(points);
            this.init();
            this.isLoaded = true;
            this.lateUpdateEvent.bind(this.onUpdate);
            this.onUpdate();
            log("Loaded");
        });
        UndoListener_1.UndoListener.getInstance(this).setPointsEditor(this);
    }
    update() {
        this.onUpdate();
    }
    hide() {
        if (this.root)
            this.root.enabled = false;
    }
    show() {
        if (this.root)
            this.root.enabled = true;
    }
    reset() {
        this.points.forEach((point, idx) => {
            point.position = this.candidePoints[idx];
            point.setLocked(Data_1.Constants.CANDIDE_POINTS[idx][1]);
        });
        this.update();
    }
    setActiveFeature(value) {
        this.activeFeatureIndex = value;
        this.activeFeatureName = this.faceStretch.getFeatureNames()[value];
        if (this.activeFeatureName == null) {
            this.hide();
            return;
        }
        this.show();
        this.updatePointsWithDeltas(this.faceStretch.getFeaturePoints(this.activeFeatureName));
        const names = this.visualStretch.getFeatureNames();
        names.forEach((name) => {
            if (name !== this.activeFeatureName) {
                this.visualStretch.setFeatureWeight(name, 0);
            }
            else {
                this.visualStretch.setFeatureWeight(name, this.faceStretch.getFeatureWeight(name));
            }
        });
        log("Loaded feature " + this.activeFeatureName);
        this.update();
    }
    setupCandidePoints(points) {
        if (points) {
            this.candidePoints = points;
        }
        else {
            Data_1.Constants.CANDIDE_POINTS.forEach((obj) => {
                this.candidePoints.push(this.normalizeCandidePoint(obj[0].x, obj[0].y));
            });
        }
    }
    normalizeCandidePoint(x, y) {
        return new vec2((x - 0.5) * 2, -(y - 0.5) * 2).add(this.offset).uniformScale(this.scaleValue);
    }
    init() {
        this.candidePoints.forEach(() => {
            this.w.push(0);
        });
        this.initPointsView();
        this.initLinesView();
        this.update();
        log("Initialized");
    }
    initLinesView() {
        const linesCount = Data_1.Constants.CANDIDE_TRIANGLES.length;
        for (let i = 0; i < linesCount; ++i) {
            for (let j = 0; j < 3; ++j) {
                const newLine = new Line_1.Line();
                newLine.pointA = this.points[Data_1.Constants.CANDIDE_TRIANGLES[i][j]];
                newLine.pointB = this.points[Data_1.Constants.CANDIDE_TRIANGLES[i][(j + 1) % 3]];
                this.lineRenderer.addLine(newLine);
            }
        }
    }
    initPointsView() {
        const pointsCount = this.candidePoints.length;
        const requestUpdate = () => this.update();
        for (let i = 0; i < pointsCount; ++i) {
            const newPoint = new Point_1.Point(this.root.copyWholeHierarchyAndAssets(this.referencePoint), i, requestUpdate);
            newPoint.position = this.candidePoints[i];
            if (i == Data_1.Constants.ALWAYS_ACTIVE_CANDIDE_POINT_IDX) {
                newPoint.setLocked(true, true);
                newPoint.breakKey();
            }
            else {
                newPoint.setLocked(Data_1.Constants.CANDIDE_POINTS[i][1]);
            }
            this.points.push(newPoint);
        }
        this.hideOverlappingPoints();
        this.setSymmetricalPoints();
        const deltas = this.activeFeatureName
            && this.faceStretch.getFeaturePoints(this.activeFeatureName);
        if (deltas) {
            this.updatePointsWithDeltas(deltas);
        }
    }
    hideOverlappingPoints() {
        Data_1.Constants.CANDIDE_OVERLAPING_POINTS_TO_HIDE.forEach((idx) => {
            this.points[idx].hide();
        });
    }
    setSymmetricalPoints() {
        Data_1.Constants.SYMMETRIC_PAIRS.forEach((pointIndex, idx) => {
            this.points[idx].setSymmetricalPoint(this.points[pointIndex]);
        });
    }
    updatePointsWithDeltas(stretchPoints) {
        let tempDeltaPos = vec2.zero();
        this.points.forEach((point, idx) => {
            tempDeltaPos.x = stretchPoints[idx].delta.x;
            tempDeltaPos.y = stretchPoints[idx].delta.y;
            point.delta = tempDeltaPos;
            point.setLocked(stretchPoints[idx].weight > 0);
        });
        log("Updated " + this.points.length + " points with deltas");
    }
    updateFaceStretch() {
        var _a;
        if (this.activeFeatureName == null)
            return;
        if (this.faceStretch.getFeatureNames().indexOf(this.activeFeatureName) == -1) {
            (_a = UndoListener_1.UndoListener.getInstance(this)) === null || _a === void 0 ? void 0 : _a.checkForUndo();
            return;
        }
        const stretchPoints = this.faceStretch.getFeaturePoints(this.activeFeatureName);
        // first -- update deformation and write deltas to core, then update dependencies
        this.applyDeformationOnInactivePointsFaster(stretchPoints);
        EffectEditor_1.EffectEditor.updateFeaturePoints(this.activeFeatureName, stretchPoints);
        this.faceStretch.updateFeaturePoints(this.activeFeatureName, stretchPoints);
        this.visualStretch.updateFeaturePoints(this.activeFeatureName, stretchPoints);
        this.updatePointsWithDeltas(stretchPoints);
    }
    applyDeformationOnInactivePointsFaster(stretchPoints) {
        const points = this.points;
        const activePoints = points.filter((p) => p.isLocked);
        let tempDeltaPos = vec3.zero();
        for (let t = 0; t < this.points.length; ++t) {
            const pt = points[t];
            const pti = pt.initialPosition;
            const ptp = pt.position;
            let totalWeight = 0;
            let rX = 0, rY = 0;
            let x = pti.x;
            let y = pti.y;
            let pXpointsNumber = 0, pYpointsNumber = 0;
            let qXpointsNumber = 0, qYpointsNumber = 0;
            if (pt.isLocked) {
                // probably introduced an inconsistency here with Studio3D: 
                // overlapping points are no longer dragged along contrary to previous impl,
                // which implicitly "locked" overlapping points,
                // most likely to affect those in CANDIDE_OVERLAPING_POINTS_TO_HIDE.
                tempDeltaPos.x = ptp.x - pti.x;
                tempDeltaPos.y = ptp.y - pti.y;
            }
            else {
                for (let i = 0; i < activePoints.length; ++i) {
                    const ap = activePoints[i];
                    const api = ap.initialPosition;
                    const density = (x - api.x) * (x - api.x) + (y - api.y) * (y - api.y);
                    const w = 1 / (density * density);
                    this.w[i] = this.LOCKED_POINT_WEIGHT * w;
                    pXpointsNumber += w * api.x;
                    pYpointsNumber += w * api.y;
                    qXpointsNumber += w * ap.position.x;
                    qYpointsNumber += w * ap.position.y;
                    totalWeight += w;
                }
                // can't be zero, because we have one point always locked,
                // but can have a quite large value, because density above may be very small
                pXpointsNumber /= totalWeight;
                pYpointsNumber /= totalWeight;
                qXpointsNumber /= totalWeight;
                qYpointsNumber /= totalWeight;
                x -= pXpointsNumber;
                y -= pYpointsNumber;
                for (let i = 0; i < activePoints.length; ++i) {
                    const api = activePoints[i].initialPosition;
                    const xInitialOff = api.x - pXpointsNumber;
                    const yInitialOff = api.y - pYpointsNumber;
                    const xInitialOffX = xInitialOff * x;
                    const yInitialOffY = yInitialOff * y;
                    const xInitialOffY = xInitialOff * y;
                    const yInitialOffX = yInitialOff * x;
                    const a = xInitialOffX + yInitialOffY;
                    const b = xInitialOffY - yInitialOffX;
                    const c = yInitialOffX - xInitialOffY;
                    const d = yInitialOffY + xInitialOffX;
                    const app = activePoints[i].position;
                    const xOff = app.x - qXpointsNumber;
                    const yOff = app.y - qYpointsNumber;
                    rX += (xOff * a + yOff * c) * this.w[i];
                    rY += (xOff * b + yOff * d) * this.w[i];
                }
                const dL = rX * rX + rY * rY;
                if (dL > 1e-10) {
                    const d = Math.sqrt((x * x + y * y) / dL);
                    tempDeltaPos.x = rX * d + qXpointsNumber - x - pXpointsNumber;
                    tempDeltaPos.y = rY * d + qYpointsNumber - y - pYpointsNumber;
                }
                else {
                    tempDeltaPos.x = 0;
                    tempDeltaPos.y = 0;
                }
            }
            stretchPoints[t].delta = tempDeltaPos;
            stretchPoints[t].weight = pt.isLocked ? this.LOCKED_POINT_WEIGHT : 0;
        }
    }
    updatePointsScale() {
        let curScale = 1.0 / this.main.getLensRegion().getPinchControl().getScale();
        this.points.forEach((point) => {
            point.setScale(curScale);
        });
    }
    processImportData(data) {
        if (!EffectEditor_1.EffectEditor.faceStretchComponent) {
            print("Select a scene object with the Face Stretch component");
            return;
        }
        let delayedEvent = this.createEvent("DelayedCallbackEvent");
        const lines = data.split('\n');
        let featureCnt = parseInt(lines[0]);
        let lineIdx = 2;
        let line;
        delayedEvent.bind(() => {
            try {
                while (featureCnt--) {
                    lineIdx++;
                    line = lines[lineIdx].split(' ');
                    let featureWeight = parseFloat(line[line.length - 1]);
                    let featureName = line[0];
                    for (let i = 1; i < line.length - 1; i++) {
                        featureName += " " + line[i];
                    }
                    if (EffectEditor_1.EffectEditor.faceStretchComponent.getFeatureNames().indexOf(featureName) == -1) {
                        EffectEditor_1.EffectEditor.faceStretchComponent.addFeature(featureName);
                    }
                    EffectEditor_1.EffectEditor.faceStretchComponent.setFeatureWeight(featureName, featureWeight);
                    lineIdx++;
                    const pointCnt = parseInt(lines[lineIdx]);
                    lineIdx++;
                    let stretchPoints = EffectEditor_1.EffectEditor.faceStretchComponent.getFeaturePoints(featureName);
                    for (var i = 0; i < pointCnt; i++) {
                        line = lines[lineIdx + i].split(' ');
                        const idx = parseInt(line[0]);
                        const weight = parseInt(line[1]);
                        const delta = vec3.zero();
                        delta.x = parseFloat(line[2]);
                        delta.y = parseFloat(line[3]);
                        delta.z = parseFloat(line[4]);
                        stretchPoints[idx].weight = weight;
                        stretchPoints[idx].delta = delta;
                    }
                    EffectEditor_1.EffectEditor.updateFeaturePoints(featureName, stretchPoints);
                    lineIdx += pointCnt;
                }
            }
            catch (e) {
                print("Invalid input data");
            }
        });
        try {
            while (featureCnt--) {
                line = lines[lineIdx].split(' ');
                let featureName = line[0];
                for (let i = 1; i < line.length - 1; i++) {
                    featureName += " " + line[i];
                }
                if (EffectEditor_1.EffectEditor.faceStretchComponent.getFeatureNames().indexOf(featureName) == -1) {
                    EffectEditor_1.EffectEditor.faceStretchComponent.addFeature(featureName);
                }
                const pointCnt = parseInt(lines[lineIdx + 1]);
                lineIdx += pointCnt + 3;
            }
            featureCnt = parseInt(lines[0]);
            lineIdx = 1;
            delayedEvent.reset(0.01);
        }
        catch (e) {
            print("Invalid input data");
        }
    }
    sendExportData() {
        if (!EffectEditor_1.EffectEditor.faceStretchComponent) {
            print("Select a scene object with the Face Stretch component");
            return;
        }
        let data;
        const featureNames = EffectEditor_1.EffectEditor.faceStretchComponent.getFeatureNames();
        data = featureNames.length + "\n";
        featureNames.forEach((featureName) => {
            data += "\n" + featureName + " " + EffectEditor_1.EffectEditor.faceStretchComponent.getFeatureWeight(featureName);
            const featurePoints = EffectEditor_1.EffectEditor.faceStretchComponent.getFeaturePoints(featureName);
            data += "\n" + featurePoints.length;
            featurePoints.forEach((point) => {
                data += "\n" + point.index + " " + point.weight + " " + point.delta.x + " " + point.delta.y + " " + point.delta.z;
            });
            data += "\n";
        });
        //@ts-ignore
        Editor.context.postMessage(FaceStretchMessages_1.ExportData.create({
            data: data
        }));
    }
    __initialize() {
        super.__initialize();
        this.LOCKED_POINT_WEIGHT = 3;
        this.scaleValue = 1.175;
        this.offset = new vec2(0, -0.075);
        this.points = [];
        this.lineRenderer = LineRenderer_1.LineRenderer.getInstance();
        this.candidePoints = [];
        this.w = [];
        this.activeFeatureIndex = 0;
        this.isLoaded = false;
        this.onUpdate = () => {
            this.lateUpdateEvent.enabled = false;
            if (this.isLoaded && this.activeFeatureIndex >= 0) {
                this.updateFaceStretch();
                this.lineRenderer.update();
            }
        };
    }
};
exports.PointsEditor = PointsEditor;
exports.PointsEditor = PointsEditor = __decorate([
    component
], PointsEditor);
function log(text) {
    return;
    text = "[PE]: " + text;
    //@ts-ignore
    if (typeof Editor !== "undefined") {
        //@ts-ignore
        Editor.print(text);
    }
    else {
        print(text);
    }
}
//# sourceMappingURL=PointsEditor.js.map