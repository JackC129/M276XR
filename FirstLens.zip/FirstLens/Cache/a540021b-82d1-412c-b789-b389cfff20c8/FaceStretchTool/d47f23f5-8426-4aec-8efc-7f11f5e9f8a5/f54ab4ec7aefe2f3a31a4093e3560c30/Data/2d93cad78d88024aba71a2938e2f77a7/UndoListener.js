"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UndoListener = void 0;
const EffectEditor_1 = require("./EffectEditor");
class UndoListener {
    static getInstance(newScript) {
        if (!this.instance) {
            this.instance = new UndoListener(newScript);
        }
        return this.instance;
    }
    constructor(script) {
        this.wasValid = true;
        script.createEvent("UpdateEvent").bind(() => {
            this.checkForUndo();
        });
        script.createEvent("LateUpdateEvent").bind(() => {
            UndoListener.isBusy = false;
        });
    }
    setFeaturesControl(featuresControl) {
        this.featureControl = featuresControl;
    }
    setPointsEditor(editor) {
        this.pointsEditor = editor;
    }
    checkForUndo() {
        if (!this.pointsEditor) {
            // log("Points edtitor not initialized");
            return;
        }
        if (UndoListener.isBusy) {
            return;
        }
        UndoListener.isBusy = true;
        if (isNull(EffectEditor_1.EffectEditor.faceStretchComponent)) {
            this.featureControl.activeFeatureIdx = -1;
            this.wasValid = false;
            log("Proxy invalid");
            return;
        }
        if (!this.wasValid) {
            this.featureControl.activeFeatureIdx = 0;
        }
        this.wasValid = true;
        if (this.featureControl) {
            this.doCheckUpdates();
        }
        else {
            log("No feature control, can't apply update");
        }
    }
    doCheckUpdates() {
        log("Check updates...");
        const fs = this.pointsEditor.faceStretch;
        const changes = diff(fs.getFeatureNames(), EffectEditor_1.EffectEditor.faceStretchComponent.getFeatureNames());
        changes.removed.length && log("Removed: " + JSON.stringify(changes.removed));
        changes.added.length && log("Added: " + JSON.stringify(changes.added));
        changes.kept.length && log("Kept: " + JSON.stringify(changes.kept));
        const featureSetChanged = changes.removed.length + changes.added.length > 0;
        let pointsChanged = false;
        changes.removed.forEach((name) => this.featureControl.forgetFeature(name));
        changes.added.forEach((name) => this.featureControl.copyFeatureFromProxy(name, true));
        changes.kept.forEach((name) => {
            if (!equalFeatures(EffectEditor_1.EffectEditor.faceStretchComponent, fs, name)) {
                log("Changed: " + name);
                this.featureControl.copyFeatureFromProxy(name, false);
                pointsChanged = true;
            }
        });
        if (changes.added.length) {
            this.featureControl.activeFeatureIdx = fs.getFeatureNames()
                .indexOf(changes.added[changes.added.length - 1]);
        }
        if (pointsChanged || featureSetChanged) {
            this.pointsEditor.setActiveFeature(this.featureControl.activeFeatureIdx);
            this.pointsEditor.update();
        }
    }
}
exports.UndoListener = UndoListener;
UndoListener.isBusy = false;
//@ts-ignore
function equalFeatures(w, s, name) {
    //@ts-ignore
    const proxyPoints = w.getFeaturePoints(name);
    const localPoints = s.getFeaturePoints(name);
    log("Comparing model with visual points " + proxyPoints.length);
    for (let j = 0; j < proxyPoints.length; j++) {
        if (!equalPoints(proxyPoints[j], localPoints[j])) {
            log("Points differ");
            return false;
        }
    }
    return true;
}
//@ts-ignore
function equalPoints(e, s) {
    return e.delta.equal(s.delta) && e.weight == s.weight;
}
function diff(ours, theirs) {
    const kept = intersect(ours, theirs);
    return {
        kept,
        added: subtract(theirs, kept),
        removed: subtract(ours, kept),
    };
}
function intersect(left, right) {
    return left.filter((v) => right.indexOf(v) != -1);
}
function subtract(left, right) {
    return left.filter((v) => right.indexOf(v) == -1);
}
function log(text) {
    return;
    text = "[UL]: " + text;
    //@ts-ignore
    if (typeof Editor !== "undefined") {
        //@ts-ignore
        Editor.print(text);
    }
    else {
        print(text);
    }
}
//# sourceMappingURL=UndoListener.js.map