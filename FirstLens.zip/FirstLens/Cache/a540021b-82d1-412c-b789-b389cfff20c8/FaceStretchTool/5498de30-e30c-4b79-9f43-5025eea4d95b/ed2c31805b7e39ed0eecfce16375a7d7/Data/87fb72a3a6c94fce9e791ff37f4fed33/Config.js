"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = void 0;
var Config;
(function (Config) {
    Config.isSymmetrical = true;
})(Config || (exports.Config = Config = {}));
//# sourceMappingURL=Config.js.map