"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ScreenPoint = void 0;
const LensRegion_1 = require("../Common/Utilities/LensRegion/LensRegion");
const SharedContent_1 = require("../Shared/SharedContent");
class ScreenPoint {
    constructor(screenObject, isIsolated) {
        this.isCursorChanged = false;
        this.isIsolated = false;
        this.onTouchStartCallback = [];
        this.onTouchEndCallback = [];
        this.onRadiusChangedCallback = [];
        this.onPositionChangedCallback = [];
        this.isIsolated = isIsolated;
        this.createNewScreenPoint(screenObject);
    }
    createNewScreenPoint(screenObject) {
        let newScreenObj = screenObject.getParent().copyWholeHierarchyAndAssets(screenObject);
        newScreenObj.enabled = true;
        this.screenPointObject = newScreenObj;
        this.interactionComp = newScreenObj.getComponent("Component.InteractionComponent");
        this.screenT = newScreenObj.getComponent("Component.ScreenTransform");
        this.childScreenT = newScreenObj.getChild(0).getComponent("ScreenTransform");
        this.pointPass = newScreenObj.getChild(0).getComponent("Image").mainPass;
        this.circlePass = newScreenObj.getComponent("Image").mainPass;
        this.cursor = newScreenObj.getComponent("ScriptComponent");
        this.setUpEvents(this.interactionComp, this.screenT);
    }
    setUpEvents(interactionComp, screenT) {
        let touchStarted = false;
        let isRadiusChange = false;
        let startScreenDistance = 0;
        let startRadius = 0;
        let prevTouchPos;
        interactionComp.onHoverStart.add((eventData) => {
            if (this.isIsolated) {
                return;
            }
            const localPosition = screenT.screenPointToLocalPoint(eventData.position);
            if (localPosition.length > 1) {
                return;
            }
            if (!this.isCursorChanged && localPosition.length > 1 - 0.1 / screenT.scale.x) {
                this.changeCursor(eventData.position);
                this.circlePass.Hover = true;
            }
        });
        interactionComp.onHover.add((eventData) => {
            if (this.isIsolated) {
                return;
            }
            if (this.isCursorChanged) {
                this.cursor.setRotation(this.getCursorAngle(eventData.position));
            }
            const localPosition = screenT.screenPointToLocalPoint(eventData.position);
            if (localPosition.length <= 1 && localPosition.length > 1 - 0.1 / screenT.scale.x) {
                if (!this.isCursorChanged) {
                    this.changeCursor(eventData.position);
                    this.circlePass.Hover = true;
                }
            }
            else {
                this.resetCursor();
                this.circlePass.Hover = false;
            }
        });
        interactionComp.onHoverEnd.add((eventData) => {
            if (this.isIsolated) {
                return;
            }
            if (this.isCursorChanged) {
                this.resetCursor();
                this.circlePass.Hover = false;
            }
        });
        interactionComp.onTouchStart.add((eventData) => {
            if (LensRegion_1.LensRegion.isBusy || this.isIsolated) {
                return;
            }
            const localPosition = screenT.screenPointToLocalPoint(eventData.position);
            if (localPosition.length > 1) {
                return;
            }
            if (this.isCursorChanged) {
                isRadiusChange = true;
                startScreenDistance = eventData.position.distance(screenT.localPointToScreenPoint(vec2.zero()));
                startRadius = screenT.scale.x;
            }
            else {
                isRadiusChange = false;
            }
            touchStarted = true;
            prevTouchPos = eventData.position;
            this.onTouchStartCallback.forEach((callback) => {
                callback(eventData.position);
            });
        });
        interactionComp.onTouchMove.add((eventData) => {
            if (this.isCursorChanged) {
                this.cursor.setRotation(this.getCursorAngle(eventData.position));
            }
            if (LensRegion_1.LensRegion.isBusy || !touchStarted || this.isIsolated) {
                touchStarted = false;
                return;
            }
            if (isRadiusChange) {
                const currentDistance = eventData.position.distance(screenT.localPointToScreenPoint(vec2.zero()));
                let factor = (startRadius * currentDistance / startScreenDistance) / screenT.scale.x;
                this.onRadiusChangedCallback.forEach((callback) => {
                    callback(factor);
                });
            }
            else {
                let diff = eventData.position.sub(prevTouchPos);
                this.onPositionChangedCallback.forEach((callback) => {
                    callback(diff);
                });
            }
            prevTouchPos = eventData.position;
        });
        interactionComp.onTouchEnd.add((eventData) => {
            if (this.isIsolated) {
                return;
            }
            touchStarted = false;
            this.onTouchEndCallback.forEach((callback) => {
                callback(eventData.position);
            });
        });
    }
    changeCursor(position) {
        this.isCursorChanged = true;
        this.cursor.setRotation(this.getCursorAngle(position));
        this.cursor.start();
    }
    resetCursor() {
        this.isCursorChanged = false;
        this.cursor.end();
    }
    getCursorAngle(cursorPos) {
        let deviceCameraTexture = SharedContent_1.SharedContent.getInstance().deviceCameraTexture;
        let aspect = deviceCameraTexture.getHeight() / deviceCameraTexture.getWidth();
        let centerPos = this.screenT.localPointToScreenPoint(vec2.zero());
        cursorPos = cursorPos.sub(centerPos);
        cursorPos.y *= aspect;
        cursorPos = cursorPos.normalize();
        return this.getAngleBetweenVectors(vec2.right(), cursorPos);
    }
    getAngleBetweenVectors(vector1, vector2) {
        var dotProduct = vector1.x * vector2.x + vector1.y * vector2.y;
        var crossProduct = vector1.x * vector2.y - vector1.y * vector2.x;
        var magnitude1 = Math.sqrt(vector1.x * vector1.x + vector1.y * vector1.y);
        var magnitude2 = Math.sqrt(vector2.x * vector2.x + vector2.y * vector2.y);
        var cosTheta = dotProduct / (magnitude1 * magnitude2);
        var radians = Math.acos(cosTheta);
        var sign = Math.sign(crossProduct);
        radians = sign * radians;
        if (radians < 0) {
            radians += 2 * Math.PI;
        }
        return -radians;
    }
    setNewRadius(newRadius) {
        this.screenT.scale = vec3.one().uniformScale(newRadius);
    }
    setRadiusFactor(factor) {
        this.screenT.scale = this.screenT.scale.uniformScale(factor);
    }
    setNewPosition(screenPos) {
        this.screenT.anchors.setCenter(screenPos);
    }
    setPositionDiff(diff) {
        if (this.isIsolated) {
            return;
        }
        let screenPos = this.screenT.localPointToScreenPoint(vec2.zero());
        this.screenT.anchors.setCenter(this.screenT.screenPointToParentPoint(screenPos.add(diff)));
    }
    hide() {
        this.screenPointObject.enabled = false;
    }
    show() {
        this.screenPointObject.enabled = true;
    }
    setDefault() {
        this.pointPass.iState = 0;
        this.circlePass.Active = false;
    }
    setActive() {
        if (this.isIsolated) {
            return;
        }
        this.pointPass.iState = 2;
        this.circlePass.Active = true;
    }
    updateScreenPointData(radius, lensRegionScale = 1) {
        this.setNewRadius(radius);
        this.childScreenT.scale = vec3.one().uniformScale(1.0 / lensRegionScale).uniformScale(1.3 / radius);
        this.circlePass.strokeThickness = (1.0 / lensRegionScale) / radius;
    }
    setIsolationStatus(status) {
        this.isIsolated = status;
    }
    addOnTouchStartCallback(callback) {
        this.onTouchStartCallback.push(callback);
    }
    addOnTouchEndCallback(callback) {
        this.onTouchEndCallback.push(callback);
    }
    addOnPositionChangedCallback(callback) {
        this.onPositionChangedCallback.push(callback);
    }
    addOnRadiusChangedCallback(callback) {
        this.onRadiusChangedCallback.push(callback);
    }
    get center() {
        return this.screenT.anchors.getCenter();
    }
    get screenPos() {
        return this.screenT.localPointToScreenPoint(vec2.zero());
    }
    get radius() {
        return this.screenT.scale.x;
    }
}
exports.ScreenPoint = ScreenPoint;
//# sourceMappingURL=ScreenPoint.js.map