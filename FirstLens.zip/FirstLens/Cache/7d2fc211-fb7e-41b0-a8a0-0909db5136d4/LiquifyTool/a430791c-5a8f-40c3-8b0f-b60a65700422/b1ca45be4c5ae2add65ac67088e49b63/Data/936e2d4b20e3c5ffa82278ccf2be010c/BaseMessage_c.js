throw new Error('This file cannot be used in a ScriptComponent. Make sure that the file has a class, decorated with @component decorator');
