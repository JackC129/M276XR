"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EffectEditor = void 0;
var __selfType = requireType("./EffectEditor");
function component(target) { target.getTypeName = function () { return __selfType; }; }
const SelectionListener_1 = require("./SelectionListener");
const Data_1 = require("../Shared/Data");
const ObjectsFinder_1 = require("./ObjectsFinder");
const PositionConverter_1 = require("./PositionConverter");
const ScreenPoint_1 = require("./ScreenPoint");
const LiquifyObjectController_1 = require("./LiquifyObjectController");
const KeyboardListener_1 = require("./KeyboardListener");
let EffectEditor = class EffectEditor extends BaseScriptComponent {
    onAwake() {
        let resolution = this.editorImage.mainPass.baseTex.control.resolution;
        this.renderTargetRatio = resolution.y / resolution.x;
        this.frameRatio = this.editorFrameHeight / (this.editorFrameWidth * this.renderTargetRatio);
        this.editorFrameRatio = this.editorFrameHeight / this.editorFrameWidth;
        this.objectsFinder = new ObjectsFinder_1.ObjectsFinder();
        let candideEvent = this.createEvent("CandideUpdatedEvent");
        candideEvent.bind(() => {
            this.points = candideEvent.points2d;
            this.setupSelectionListener();
            candideEvent.enabled = false;
        });
        this.main.addPinchOnUpdateCallback(() => {
            this.updateScreenPointData();
            this.updateSnappingCirclesScale();
        });
        this.lensRegion.addOnLensRegionUpdate(() => {
            this.updateLiquifyObjScale();
            this.updateScreenPointData();
            this.updateSnappingCirclesScale();
        });
    }
    //@ts-ignore
    getFirstSelectedObject() {
        return this.selectedObjects[Object.keys(this.selectedObjects)[0]];
    }
    setFaceLiquifyRadius(objId) {
        this.faceLiquifyObjects[objId].liquifyObjectController.radius = this.faceLiquifyObjects[objId].screenPoint.radius;
    }
    setFaceLiquifyPosition(screenPos, objId) {
        screenPos.y *= this.frameRatio;
        //@ts-ignore
        this.faceLiquifyObjects[objId].liquifyObjectController.headComp.attachmentPoint = Editor.Components.HeadAttachmentPointType.TriangleBarycentric;
        let vertex = this.faceLiquifyObjects[objId].liquifyObjectController.headComp.attachedBarycentricVertex;
        let barycentricCoords = PositionConverter_1.PositionConverter.getInstance().getBarycentricCoordinates(screenPos, this.editorFrameRatio, this.points, vertex.indices, Data_1.Constants.CANDIDE_TRIANGLES);
        vertex.indices = [barycentricCoords.indices[0], barycentricCoords.indices[1], barycentricCoords.indices[2]];
        vertex.weights = [barycentricCoords.weights[0], barycentricCoords.weights[1], barycentricCoords.weights[2]];
        this.faceLiquifyObjects[objId].liquifyObjectController.headComp.attachedBarycentricVertex = vertex;
        this.faceLiquifyObjects[objId].liquifyObjectController.setWorldPosition(screenPos, this.renderTargetRatio);
    }
    setupSelectionListener() {
        this.selectionListener = new SelectionListener_1.SelectionListener(this);
        this.selectionListener.setOnSelectionUpdate(() => {
            this.update();
        });
        this.createEvent("UpdateEvent").bind(() => {
            this.copyTo();
        });
    }
    update() {
        this.selectedObjects = this.selectionListener.getSelectedObjects();
    }
    copyTo() {
        if (this.touchStarted) {
            return;
        }
        for (let objId of Object.keys(this.faceLiquifyObjects)) {
            this.faceLiquifyObjects[objId].liquifyObjectController.hide();
            this.faceLiquifyObjects[objId].screenPoint.hide();
        }
        let objs = this.objectsFinder.getLiquifyObjs();
        let isSelected = false;
        for (let objId of Object.keys(objs)) {
            if (!this.faceLiquifyObjects[objId]) {
                this.createNewLiquify(objId);
                this.faceLiquifyObjects[objId].liquifyObjectController.updateComponents(objs[objId].headComponent, objs[objId].liquifyComponent, objs[objId].sceneObject);
                this.faceLiquifyObjects[objId].liquifyObjectController.updateLiquifyData();
                this.faceLiquifyObjects[objId].screenPoint.updateScreenPointData(this.faceLiquifyObjects[objId].liquifyObjectController.radius, this.main.getLensRegion().getPinchControl().getScale());
            }
            if (this.selectedObjects[objId]) {
                this.faceLiquifyObjects[objId].liquifyObjectController.updateComponents(objs[objId].headComponent, objs[objId].liquifyComponent, objs[objId].sceneObject);
            }
            if (this.faceLiquifyObjects[objId].liquifyObjectController.isValid) {
                if (!this.faceLiquifyObjects[objId].liquifyObjectController.isSameAttachmentPoint) {
                    if (Data_1.Constants.BARYCENTRIC_VERTICES[this.faceLiquifyObjects[objId].liquifyObjectController.attachmentPoint]) {
                        let vertex = Data_1.Constants.BARYCENTRIC_VERTICES[this.faceLiquifyObjects[objId].liquifyObjectController.attachmentPoint];
                        this.setFaceRegionCoords(objId, vertex);
                    }
                    else {
                        //@ts-ignore
                        if (this.faceLiquifyObjects[objId].liquifyObjectController.headComp.attachmentPoint == Editor.Components.HeadAttachmentPointType.TriangleBarycentric) {
                            let vertex = this.faceLiquifyObjects[objId].liquifyObjectController.headComp.attachedBarycentricVertex;
                            this.setFaceRegionCoords(objId, vertex);
                        }
                    }
                    this.faceLiquifyObjects[objId].liquifyObjectController.updateAttachmentPoint();
                }
                this.faceLiquifyObjects[objId].liquifyObjectController.show();
                this.faceLiquifyObjects[objId].screenPoint.show();
                if (this.selectedObjects[objId]) {
                    isSelected = true;
                    this.faceLiquifyObjects[objId].screenPoint.setActive();
                    this.faceLiquifyObjects[objId].liquifyObjectController.updateLiquifyData();
                    this.faceLiquifyObjects[objId].screenPoint.updateScreenPointData(this.faceLiquifyObjects[objId].liquifyObjectController.radius, this.main.getLensRegion().getPinchControl().getScale());
                }
                else {
                    this.faceLiquifyObjects[objId].screenPoint.setDefault();
                }
            }
        }
    }
    setDefaultToPoints() {
        for (let objId of Object.keys(this.faceLiquifyObjects)) {
            this.faceLiquifyObjects[objId].screenPoint.setDefault();
        }
    }
    createNewLiquify(objId) {
        this.faceLiquifyObjects[objId] = {};
        this.faceLiquifyObjects[objId].liquifyObjectController = new LiquifyObjectController_1.LiquifyObjectController(this.liquifyObj, this.isIsolationMode);
        this.faceLiquifyObjects[objId].liquifyObjectController.setWorldScale(this.renderTargetRatio);
        this.faceLiquifyObjects[objId].screenPoint = new ScreenPoint_1.ScreenPoint(this.screenPointObj, this.isIsolationMode);
        this.faceLiquifyObjects[objId].screenPoint.addOnTouchStartCallback((position) => {
            this.touchStarted = true;
            if (!this.selectedObjects[objId]) {
                //@ts-ignore
                if (!KeyboardListener_1.KeyboardListener.isKeyPressed(Keys.Key_Control)) {
                    this.setDefaultToPoints();
                    this.selectionListener.setNewSelectedObject(this.faceLiquifyObjects[objId].liquifyObjectController.lsObject);
                }
                else {
                    this.selectionListener.addSelectedObject(this.faceLiquifyObjects[objId].liquifyObjectController.lsObject);
                }
                this.faceLiquifyObjects[objId].screenPoint.setActive();
            }
        });
        this.faceLiquifyObjects[objId].screenPoint.addOnTouchEndCallback((position) => {
            this.touchStarted = false;
            if (this.isSnappingMode) {
                this.snappingScript.hide();
            }
        });
        this.faceLiquifyObjects[objId].screenPoint.addOnPositionChangedCallback((diff) => {
            if (this.isSnappingMode && !this.snappingScript.isShown) {
                this.snappingScript.show();
                Object.keys(this.faceLiquifyObjects).forEach((idx) => {
                    if (!this.selectedObjects[idx] && this.faceLiquifyObjects[idx].liquifyObjectController.isValid) {
                        this.snappingScript.addSnappingPoint(this.faceLiquifyObjects[idx].screenPoint.center);
                    }
                });
            }
            if (this.isSnappingMode) {
                let pointsData = [];
                Object.keys(this.selectedObjects).forEach((idx, i) => {
                    if (!this.faceLiquifyObjects[idx]) {
                        return;
                    }
                    if (this.isSymmetricMode && objId != idx) {
                        pointsData.push({
                            pointPos: this.faceLiquifyObjects[idx].screenPoint.screenPos,
                            isSymmetrical: true
                        });
                    }
                    else {
                        pointsData.push({
                            pointPos: this.faceLiquifyObjects[idx].screenPoint.screenPos,
                            isSymmetrical: false
                        });
                    }
                });
                diff = this.snappingScript.checkNewDiff(pointsData, diff);
            }
            this.manipulateSelectedPoints(objId, diff);
        });
        this.faceLiquifyObjects[objId].screenPoint.addOnRadiusChangedCallback((factor) => {
            Object.keys(this.selectedObjects).forEach((idx) => {
                if (!this.faceLiquifyObjects[idx]) {
                    return;
                }
                this.faceLiquifyObjects[idx].screenPoint.setRadiusFactor(factor);
                this.faceLiquifyObjects[idx].screenPoint.updateScreenPointData(this.faceLiquifyObjects[idx].screenPoint.radius, this.main.getLensRegion().getPinchControl().getScale());
                this.setFaceLiquifyRadius(idx);
            });
        });
    }
    manipulateSelectedPoints(objId, diff) {
        Object.keys(this.selectedObjects).forEach((idx, i) => {
            if (!this.faceLiquifyObjects[idx]) {
                return;
            }
            let xRatio = 1;
            if (this.isSymmetricMode && objId != idx) {
                xRatio = -1;
                diff.x *= xRatio;
            }
            this.faceLiquifyObjects[idx].screenPoint.setPositionDiff(diff);
            diff.x *= xRatio;
            this.setFaceLiquifyPosition(this.faceLiquifyObjects[idx].screenPoint.center, idx);
        });
    }
    setFaceRegionCoords(objId, vertex) {
        let screenPos = PositionConverter_1.PositionConverter.getInstance().barycentricToCoordinates(this.points[vertex.indices[0]], this.points[vertex.indices[1]], this.points[vertex.indices[2]], vertex.weights);
        screenPos.y /= this.frameRatio;
        this.faceLiquifyObjects[objId].screenPoint.setNewPosition(screenPos);
        this.updateWorldPosition(objId);
    }
    updateWorldPosition(id) {
        let screenPos = this.faceLiquifyObjects[id].screenPoint.center;
        screenPos.y *= this.frameRatio;
        this.faceLiquifyObjects[id].liquifyObjectController.setWorldPosition(screenPos, this.renderTargetRatio);
    }
    updateLiquifyObjScale() {
        for (let objId of Object.keys(this.faceLiquifyObjects)) {
            this.updateWorldPosition(objId);
            this.faceLiquifyObjects[objId].liquifyObjectController.setWorldScale(this.renderTargetRatio);
        }
    }
    updateScreenPointData() {
        for (let objId of Object.keys(this.faceLiquifyObjects)) {
            this.faceLiquifyObjects[objId].screenPoint.updateScreenPointData(this.faceLiquifyObjects[objId].liquifyObjectController.radius, this.main.getLensRegion().getPinchControl().getScale());
        }
    }
    updateSnappingCirclesScale() {
        this.snappingScript.updateScreenCircleScale(this.main.getLensRegion().getPinchControl().getScale());
    }
    setIsolationStatus(status) {
        this.isIsolationMode = status;
        for (let objId of Object.keys(this.faceLiquifyObjects)) {
            if (!this.selectedObjects[objId]) {
                this.faceLiquifyObjects[objId].screenPoint.setIsolationStatus(status);
                this.faceLiquifyObjects[objId].liquifyObjectController.setIsolationStatus(status);
            }
            else {
                this.faceLiquifyObjects[objId].screenPoint.setIsolationStatus(false);
                this.faceLiquifyObjects[objId].liquifyObjectController.setIsolationStatus(false);
            }
        }
    }
    setSymmetricStatus(status) {
        this.isSymmetricMode = status;
    }
    setSnappingStatus(status) {
        this.isSnappingMode = status;
    }
    clearSelection() {
        this.setDefaultToPoints();
        this.selectionListener.clearSelection();
    }
    __initialize() {
        super.__initialize();
        this.selectedObjects = {};
        this.points = [];
        this.faceLiquifyObjects = {};
        this.touchStarted = false;
        this.frameRatio = 1.0;
        this.editorFrameRatio = 1.0;
        this.renderTargetRatio = 1.0;
        this.isIsolationMode = false;
        this.isSymmetricMode = false;
        this.isSnappingMode = false;
    }
};
exports.EffectEditor = EffectEditor;
exports.EffectEditor = EffectEditor = __decorate([
    component
], EffectEditor);
//# sourceMappingURL=EffectEditor.js.map