"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Snapping = void 0;
var __selfType = requireType("./Snapping");
function component(target) { target.getTypeName = function () { return __selfType; }; }
let Snapping = class Snapping extends BaseScriptComponent {
    onAwake() {
        this.parentScreenT = this.editorFrame.getComponent("ScreenTransform");
        this.initLocalPositions.push(new vec2(-0.287, 0.0034));
        this.initLocalPositions.push(new vec2(0.287, 0.0034));
        this.initLocalPositions.push(new vec2(-0.005922, -0.082768));
        this.initLocalPositions.push(new vec2(-0.0035657, -0.356853));
        this.initLocalPositions.forEach((pos) => {
            let newCircle = this.spawnNewGreenCircle(pos);
            this.initObjects.push(newCircle.obj);
            this.initObjectsScreenT.push(newCircle.screenT);
        });
    }
    checkNewDiff(pointsData, diff) {
        let minDist = Number.MAX_VALUE;
        this.lineRenderer.reset();
        let pointsPositions = [];
        pointsData.forEach((pointData) => {
            let curDiff = vec2.zero();
            curDiff.x = diff.x;
            curDiff.y = diff.y;
            if (pointData.isSymmetrical) {
                curDiff.x *= -1;
            }
            pointsPositions.push(pointData.pointPos.add(curDiff));
        });
        //--------------------
        let initPositions = [];
        this.initLocalPositions.forEach((pos) => {
            initPositions.push(this.parentScreenT.localPointToScreenPoint(pos));
        });
        let closestInitPoint = this.getClosestIndices(initPositions, pointsPositions, minDist);
        let spawnedPositions = [];
        for (let i = 0; i <= this.spawnedObjectIdx; i++) {
            spawnedPositions.push(this.parentScreenT.localPointToScreenPoint(this.spawnedObjectsScreenT[i].anchors.getCenter()));
        }
        let closestSpawnedPoint = this.getClosestIndices(spawnedPositions, pointsPositions, minDist);
        //--------------------
        let closestPoint = null;
        if (closestSpawnedPoint.wasFound) {
            closestPoint = { wasFound: true, minDist: closestSpawnedPoint.minDist, greenPointPos: spawnedPositions[closestSpawnedPoint.greenPointIdx],
                pointPos: pointsPositions[closestSpawnedPoint.pointIdx], isSymmetrical: pointsData[closestSpawnedPoint.pointIdx].isSymmetrical };
        }
        else {
            if (closestInitPoint.wasFound) {
                closestPoint = { wasFound: true, minDist: closestInitPoint.minDist, greenPointPos: initPositions[closestInitPoint.greenPointIdx],
                    pointPos: pointsPositions[closestInitPoint.pointIdx], isSymmetrical: pointsData[closestInitPoint.pointIdx].isSymmetrical };
            }
            else {
                closestPoint = { wasFound: false };
            }
        }
        //--------------------
        let otherCirclesPos = [];
        for (let i = 0; i <= this.spawnedObjectIdx; i++) {
            let spawnedObjCenter = this.spawnedObjectsScreenT[i].anchors.getCenter();
            spawnedObjCenter.x *= -1;
            otherCirclesPos.push(this.parentScreenT.localPointToScreenPoint(spawnedObjCenter));
        }
        let closestLines = this.getClosestLines(otherCirclesPos, pointsPositions);
        if (closestLines.horizontal.wasFound) {
            closestLines.horizontal.circlePos = otherCirclesPos[closestLines.horizontal.circleIdx];
            closestLines.horizontal.isSymmetrical = pointsData[closestLines.horizontal.pointIdx].isSymmetrical;
        }
        if (closestLines.vertical.wasFound) {
            closestLines.vertical.circlePos = otherCirclesPos[closestLines.vertical.circleIdx];
            closestLines.vertical.isSymmetrical = pointsData[closestLines.vertical.pointIdx].isSymmetrical;
        }
        //--------------------
        let offset = this.getOffset(closestPoint, closestLines);
        if (offset.wasFound) {
            if (offset.isHorizontalLine) {
                this.addLine(closestLines.horizontal.circlePos, pointsPositions[closestLines.horizontal.pointIdx].add(offset.offset));
            }
            if (offset.isVerticalLine) {
                this.addLine(closestLines.vertical.circlePos, pointsPositions[closestLines.vertical.pointIdx].add(offset.offset));
            }
            if (offset.isSymmetrical) {
                offset.offset.x *= -1;
            }
            this.touchDiff = this.touchDiff.sub(offset.offset);
            diff = diff.add(offset.offset);
        }
        else {
            diff = diff.add(this.touchDiff);
            this.touchDiff = vec2.zero();
        }
        return diff;
    }
    getOffset(closestPoint, closestLines) {
        let offset = vec2.zero();
        let isHorizontalLine = false;
        let isVerticalLine = false;
        if (closestLines.horizontal.wasFound && (!closestLines.vertical.wasFound || closestLines.horizontal.minDist < closestLines.vertical.minDist) &&
            (!closestPoint.wasFound || closestLines.horizontal.minDist < closestPoint.minDist)) {
            offset.y = closestLines.horizontal.diff;
            isHorizontalLine = true;
            if (closestLines.vertical.wasFound && (!closestPoint.wasFound || closestLines.vertical.minDist < closestPoint.minDist)) {
                offset.x = closestLines.vertical.diff;
                isVerticalLine = true;
            }
            else {
                if (closestPoint.wasFound && Math.abs(closestPoint.greenPointPos.y - closestLines.horizontal.circlePos.y) < this.EPS) {
                    offset.x = closestPoint.greenPointPos.x - closestPoint.pointPos.x;
                }
            }
            return { offset: offset, isSymmetrical: closestLines.horizontal.isSymmetrical, wasFound: true, isHorizontalLine: isHorizontalLine, isVerticalLine: isVerticalLine };
        }
        if (closestLines.vertical.wasFound && (!closestLines.horizontal.wasFound || closestLines.vertical.minDist < closestLines.horizontal.minDist) &&
            (!closestPoint.wasFound || closestLines.vertical.minDist < closestPoint.minDist)) {
            offset.x = closestLines.vertical.diff;
            isVerticalLine = true;
            if (closestLines.horizontal.wasFound && (!closestPoint.wasFound || closestLines.horizontal.minDist < closestPoint.minDist)) {
                offset.y = closestLines.horizontal.diff;
                isHorizontalLine = true;
            }
            else {
                if (closestPoint.wasFound && Math.abs(closestPoint.greenPointPos.x - closestLines.vertical.circlePos.x) < this.EPS) {
                    offset.y = closestPoint.greenPointPos.y - closestPoint.pointPos.y;
                }
            }
            return { offset: offset, isSymmetrical: closestLines.vertical.isSymmetrical, wasFound: true, isHorizontalLine: isHorizontalLine, isVerticalLine: isVerticalLine };
        }
        if (closestPoint.wasFound) {
            offset = closestPoint.greenPointPos.sub(closestPoint.pointPos);
            return { offset: offset, isSymmetrical: closestPoint.isSymmetrical, wasFound: true, isHorizontalLine: isHorizontalLine, isVerticalLine: isVerticalLine };
        }
        return { offset: offset, isSymmetrical: false, wasFound: false, isHorizontalLine: isHorizontalLine, isVerticalLine: isVerticalLine };
    }
    getClosestIndices(greenPointsPositions, pointsPositions, minDist) {
        let greenPointIdx = -1;
        let pointIdx = -1;
        let wasFound = false;
        greenPointsPositions.forEach((greenCirclePos, gIdx) => {
            pointsPositions.forEach((pointPos, pIdx) => {
                let curDist = pointPos.add(this.touchDiff).distance(greenCirclePos);
                if (curDist < minDist && curDist < this.closestDistToPoint) {
                    wasFound = true;
                    minDist = curDist;
                    greenPointIdx = gIdx;
                    pointIdx = pIdx;
                }
            });
        });
        return { wasFound: wasFound, minDist: minDist, greenPointIdx: greenPointIdx, pointIdx: pointIdx };
    }
    getClosestLines(otherPointsPosition, pointsPosition) {
        let horizontalPointIdx = -1;
        let horizontalCircleIdx = -1;
        let minDistX = Number.MAX_VALUE;
        let diffX = 0;
        let verticalPointIdx = -1;
        let verticalCircleIdx = -1;
        let minDistY = Number.MAX_VALUE;
        let diffY = 0;
        otherPointsPosition.forEach((otherCirclePos, initIdx) => {
            pointsPosition.forEach((pointPos, pointIdx) => {
                let curDistX = Math.abs((pointPos.x + this.touchDiff.x) - otherCirclePos.x);
                if (curDistX < this.closestDistToPoint && curDistX < minDistX) {
                    verticalPointIdx = pointIdx;
                    verticalCircleIdx = initIdx;
                    minDistX = curDistX;
                    diffX = otherCirclePos.x - pointPos.x;
                }
                let curDistY = Math.abs((pointPos.y + this.touchDiff.y) - otherCirclePos.y);
                if (curDistY < this.closestDistToPoint && curDistY < minDistY) {
                    horizontalPointIdx = pointIdx;
                    horizontalCircleIdx = initIdx;
                    minDistY = curDistY;
                    diffY = otherCirclePos.y - pointPos.y;
                }
            });
        });
        return { horizontal: { wasFound: horizontalPointIdx >= 0, pointIdx: horizontalPointIdx, circleIdx: horizontalCircleIdx, minDist: minDistY, diff: diffY, circlePos: null, isSymmetrical: null },
            vertical: { wasFound: verticalPointIdx >= 0, pointIdx: verticalPointIdx, circleIdx: verticalCircleIdx, minDist: minDistX, diff: diffX, circlePos: null, isSymmetrical: null } };
    }
    addLine(screenPos1, screenPos2) {
        let worldPoint1 = this.camera.screenSpaceToWorldSpace(screenPos1, 10);
        let worldPoint2 = this.camera.screenSpaceToWorldSpace(screenPos2, 10);
        this.lineRenderer.addLine(worldPoint1, worldPoint2);
        this.lineRenderer.update();
    }
    addSnappingPoint(pos) {
        this.spawnedObjectIdx++;
        pos.x *= -1;
        if (this.spawnedObjectIdx == this.spawnedObjects.length) {
            let newCircle = this.spawnNewGreenCircle(pos);
            newCircle.obj.enabled = true;
            this.spawnedObjects.push(newCircle.obj);
            this.spawnedObjectsScreenT.push(newCircle.screenT);
        }
        else {
            this.spawnedObjects[this.spawnedObjectIdx].enabled = true;
            this.spawnedObjectsScreenT[this.spawnedObjectIdx].anchors.setCenter(pos);
        }
    }
    spawnNewGreenCircle(pos) {
        let newCircle = this.editorFrame.copyWholeHierarchyAndAssets(this.greenCircle);
        let newCircleScreenT = newCircle.getComponent("ScreenTransform");
        newCircleScreenT.anchors.setCenter(pos);
        return { obj: newCircle, screenT: newCircleScreenT };
    }
    updateScreenCircleScale(lensRegionScale = 1) {
        this.initObjectsScreenT.forEach((screenT) => {
            screenT.scale = vec3.one().uniformScale(1 / lensRegionScale);
        });
        this.spawnedObjectsScreenT.forEach((screenT) => {
            screenT.scale = vec3.one().uniformScale(1 / lensRegionScale);
        });
        this.lineRenderer.reset();
    }
    show() {
        this.touchDiff = vec2.zero();
        this.shown = true;
        this.lineRenderer.reset();
        this.initObjects.forEach((obj) => {
            obj.enabled = true;
        });
    }
    hide() {
        this.shown = false;
        this.touchDiff = vec2.zero();
        this.lineRenderer.reset();
        this.spawnedObjectIdx = -1;
        this.initObjects.forEach((obj) => {
            obj.enabled = false;
        });
        this.spawnedObjects.forEach((obj) => {
            obj.enabled = false;
        });
    }
    get positionIsFixed() {
        return this.posIsFixed;
    }
    get isShown() {
        return this.shown;
    }
    __initialize() {
        super.__initialize();
        this.closestDistToPoint = 0.02;
        this.EPS = 1e5;
        this.touchDiff = vec2.zero();
        this.posIsFixed = false;
        this.shown = false;
        this.initLocalPositions = [];
        this.initObjects = [];
        this.initObjectsScreenT = [];
        this.spawnedObjectIdx = -1;
        this.spawnedObjects = [];
        this.spawnedObjectsScreenT = [];
    }
};
exports.Snapping = Snapping;
exports.Snapping = Snapping = __decorate([
    component
], Snapping);
//# sourceMappingURL=Snapping.js.map