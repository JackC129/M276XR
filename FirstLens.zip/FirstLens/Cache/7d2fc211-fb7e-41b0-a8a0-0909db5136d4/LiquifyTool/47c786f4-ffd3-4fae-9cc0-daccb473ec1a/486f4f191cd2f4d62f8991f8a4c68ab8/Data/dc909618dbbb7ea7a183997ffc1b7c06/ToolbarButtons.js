"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolbarButtons = void 0;
var __selfType = requireType("./ToolbarButtons");
function component(target) { target.getTypeName = function () { return __selfType; }; }
const MessageCenter_1 = require("./MessageCenter/MessageCenter");
const LiquifyMessages_1 = require("./MessageCenter/MessageTypes/LiquifyMessages");
let ToolbarButtons = class ToolbarButtons extends BaseScriptComponent {
    onAwake() {
        MessageCenter_1.MessageCenter.instance.subscribe(LiquifyMessages_1.AddButtonMessage, (message) => {
            this.spawnNewFaceLiquify();
        });
        MessageCenter_1.MessageCenter.instance.subscribe(LiquifyMessages_1.CandideButtonMessage, (message) => {
            //@ts-ignore
            this.faceGridObject.enabled = message.checked;
        });
        MessageCenter_1.MessageCenter.instance.subscribe(LiquifyMessages_1.SymmetricModeButtonMessage, (message) => {
            //@ts-ignore
            this.effectEditor.setSymmetricStatus(message.checked);
        });
        MessageCenter_1.MessageCenter.instance.subscribe(LiquifyMessages_1.SnappingButtonMessage, (message) => {
            //@ts-ignore
            this.effectEditor.setSnappingStatus(message.checked);
        });
        MessageCenter_1.MessageCenter.instance.subscribe(LiquifyMessages_1.IsolateButtonMessage, (message) => {
            //@ts-ignore
            this.effectEditor.setIsolationStatus(message.checked);
        });
        MessageCenter_1.MessageCenter.instance.subscribe(LiquifyMessages_1.ResetButtonMessage, (message) => {
            this.main.getLensRegion().resetPosition();
            this.main.getLensRegion().resetScale();
        });
    }
    spawnNewFaceLiquify() {
        //@ts-ignore
        const selectedObject = this.effectEditor.getFirstSelectedObject();
        var parent = null;
        if (selectedObject) {
            parent = selectedObject.getParent();
        }
        //@ts-ignore
        const newObject = Editor.context.scene.addSceneObject(parent);
        newObject.name = "Liquify Visual";
        //@ts-ignore
        const head = newObject.addComponent("Head");
        //@ts-ignore
        head.attachmentPoint = Editor.Components.HeadAttachmentPointType.CandideCenter;
        //@ts-ignore
        const liquify = newObject.addComponent("LiquifyVisual");
        liquify.radius = 2;
    }
};
exports.ToolbarButtons = ToolbarButtons;
exports.ToolbarButtons = ToolbarButtons = __decorate([
    component
], ToolbarButtons);
//# sourceMappingURL=ToolbarButtons.js.map