"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LiquifyObjectController = void 0;
const SharedContent_1 = require("../Shared/SharedContent");
const PositionConverter_1 = require("./PositionConverter");
class LiquifyObjectController {
    constructor(liquifyObj, isIsolated) {
        //@ts-ignore
        this.prevAttachmentPoint = null;
        this.createNewLiquifyObject(liquifyObj);
        this.liquifyComponent.enabled = !isIsolated;
    }
    createNewLiquifyObject(liquifyObj) {
        let newLiquifyObj = liquifyObj.getParent().copyWholeHierarchy(liquifyObj);
        newLiquifyObj.enabled = true;
        this.liquifyObject = newLiquifyObj;
        this.liquifyObjT = newLiquifyObj.getTransform();
        this.liquifyComponent = newLiquifyObj.getComponent("Component.LiquifyVisual");
    }
    //@ts-ignore
    updateComponents(headComponent, fijiComp, fijiObject) {
        this.headComponent = headComponent;
        this.fijiComponent = fijiComp;
        this.fijiObject = fijiObject;
    }
    updateLiquifyData() {
        this.liquifyComponent.radius = this.fijiComponent.radius;
        this.liquifyComponent.intensity = this.fijiComponent.intensity;
    }
    setWorldPosition(screenPos, renderTargetRatio) {
        screenPos.x = (1 + screenPos.x) / 2;
        screenPos.y = 1 - (1 + screenPos.y) / 2;
        let normal = SharedContent_1.SharedContent.getInstance().worldCamera.screenSpaceToWorldSpace(screenPos, 1);
        normal = normal.normalize();
        let worldPos = PositionConverter_1.PositionConverter.getInstance().planeLineIntersection(normal, -17);
        this.liquifyObjT.setWorldPosition(worldPos);
    }
    setWorldScale(renderTargetRatio) {
        let deviceCameraTexture = SharedContent_1.SharedContent.getInstance().deviceCameraTexture;
        let aspect = deviceCameraTexture.getHeight() / deviceCameraTexture.getWidth();
        let scale = this.liquifyObjT.getWorldScale();
        scale.y = aspect / renderTargetRatio;
        this.liquifyObjT.setWorldScale(scale);
    }
    hide() {
        this.liquifyObject.enabled = false;
    }
    show() {
        this.liquifyObject.enabled = true;
    }
    selectFijiObject() {
        //@ts-ignore
        Editor.context.selection.set([this.fijiObject]);
    }
    updateAttachmentPoint() {
        this.prevAttachmentPoint = this.headComponent.attachmentPoint;
    }
    setIsolationStatus(status) {
        this.liquifyComponent.enabled = !status;
    }
    get isValid() {
        return !isNull(this.fijiObject) && !isNull(this.fijiComponent) && this.fijiObject.enabled && this.fijiComponent.enabled;
    }
    get radius() {
        return this.liquifyComponent.radius;
    }
    set radius(newRadius) {
        this.liquifyComponent.radius = newRadius;
        this.fijiComponent.radius = newRadius;
    }
    //@ts-ignore
    get headComp() {
        return this.headComponent;
    }
    //@ts-ignore
    get attachmentPoint() {
        return this.headComponent.attachmentPoint;
    }
    get isSameAttachmentPoint() {
        return this.headComponent.attachmentPoint === this.prevAttachmentPoint;
    }
    //@ts-ignore
    get lsObject() {
        return this.fijiObject;
    }
}
exports.LiquifyObjectController = LiquifyObjectController;
//# sourceMappingURL=LiquifyObjectController.js.map