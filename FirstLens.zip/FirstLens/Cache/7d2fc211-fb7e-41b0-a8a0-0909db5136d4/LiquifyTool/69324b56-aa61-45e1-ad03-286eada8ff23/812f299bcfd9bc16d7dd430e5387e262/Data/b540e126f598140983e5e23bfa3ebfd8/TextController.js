"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TextController = void 0;
var __selfType = requireType("./TextController");
function component(target) { target.getTypeName = function () { return __selfType; }; }
let TextController = class TextController extends BaseScriptComponent {
    onAwake() {
        this.main.addPinchOnUpdateCallback(() => {
            this.updateZoomText();
        });
    }
    updateZoomText() {
        this.zoomText.text = "Zoom: " + Math.floor(this.main.getLensRegion().getPinchControl().getScale() * 100) + "%";
    }
};
exports.TextController = TextController;
exports.TextController = TextController = __decorate([
    component
], TextController);
//# sourceMappingURL=TextController.js.map