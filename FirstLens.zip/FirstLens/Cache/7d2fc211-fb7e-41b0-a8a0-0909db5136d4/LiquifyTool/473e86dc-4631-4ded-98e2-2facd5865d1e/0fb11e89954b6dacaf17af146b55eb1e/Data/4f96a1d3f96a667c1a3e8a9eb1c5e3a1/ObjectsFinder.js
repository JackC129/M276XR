"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ObjectsFinder = void 0;
class ObjectsFinder {
    getLiquifyObjs() {
        //@ts-ignore
        if (typeof Editor === 'undefined') {
            return [];
        }
        let objs = {};
        //@ts-ignore
        let liquifyComponents = Editor.context.scene.findComponents("LiquifyVisual");
        if (liquifyComponents.length > 0) {
            liquifyComponents.forEach((comp) => {
                let sceneObject = comp.sceneObject;
                //@ts-ignore
                let liquifyComps = sceneObject.getComponents("LiquifyVisual");
                //@ts-ignore
                let headComps = sceneObject.getComponents("Head");
                if (liquifyComps.length == 1 && headComps.length == 1) {
                    let curId = sceneObject.id.toString();
                    objs[curId] = { "sceneObject": sceneObject, "liquifyComponent": liquifyComps[0], "headComponent": headComps[0] };
                }
            });
        }
        return objs;
    }
}
exports.ObjectsFinder = ObjectsFinder;
//# sourceMappingURL=ObjectsFinder.js.map