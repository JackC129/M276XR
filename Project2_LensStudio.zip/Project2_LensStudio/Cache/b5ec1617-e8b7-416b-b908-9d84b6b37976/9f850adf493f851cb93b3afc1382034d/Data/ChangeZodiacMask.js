//@input SceneObject[] headBindings // Array of the 12 head binding objects
//@input Component.Text promptText // The initial "Tap To Get Your Zodiac Mask" text
//@input Component.Touch touchBehavior // The touch interaction behavior

// Initialize a variable to keep track of the current head binding index
var currentIndex = 0;

// Function to change the head binding (i.e., the Zodiac mask)
function changeHeadBinding() {
    // Hide all head bindings
    for (var i = 0; i < script.headBindings.length; i++) {
        script.headBindings[i].enabled = false;
    }

    // Show the current head binding (Zodiac mask)
    script.headBindings[currentIndex].enabled = true;

    // Update the current index to the next head binding
    currentIndex = (currentIndex + 1) % script.headBindings.length;
}

// Function to hide the prompt text
function hidePromptText() {
    script.promptText.enabled = false;
}

// Add event listener to detect tap interaction
script.touchBehavior.onTap.add(function() {
    // On the first tap, hide the prompt and start showing masks
    if (script.promptText.enabled) {
        hidePromptText();
    }

    // Change the head binding (Zodiac mask)
    changeHeadBinding();
});

// Initialize by showing the first mask and showing the prompt text
changeHeadBinding();
