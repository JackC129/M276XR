//@input Component.TouchScreenInteraction touchInteraction

// Define the callback for tap interaction
function onTap() {
    // Emit a custom event or handle tap logic here.
    global.eventBus.emit("tapOccurred");
}

// Listen for tap events
script.touchInteraction.onTap.add(onTap);
