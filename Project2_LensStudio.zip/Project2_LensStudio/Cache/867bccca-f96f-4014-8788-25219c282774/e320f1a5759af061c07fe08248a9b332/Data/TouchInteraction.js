//@input SceneObject[] headBindings // Array of 12 head binding objects (Zodiac masks)
//@input Component.Text promptText // The "Tap To Get Your Zodiac Mask" text
//@input Component.Camera camera // The camera component to handle screen touches

// Initialize a variable to keep track of the current head binding index
var currentIndex = 0;

// Function to change the head binding (i.e., Zodiac mask)
function changeHeadBinding() {
    // Hide all head bindings
    for (var i = 0; i < script.headBindings.length; i++) {
        script.headBindings[i].enabled = false;
    }

    // Show the current head binding (Zodiac mask)
    script.headBindings[currentIndex].enabled = true;

    // Update the current index to the next head binding
    currentIndex = (currentIndex + 1) % script.headBindings.length;
}

// Function to hide the prompt text
function hidePromptText() {
    script.promptText.enabled = false;
}

// Listen for touch event (tap)
var touchEvent = script.createEvent("TouchEvent");

// Event handler for touch interactions
touchEvent.bind(function(eventData) {
    // Check if the touch was a tap (you can customize this for other touch events)
    if (eventData.action == "tap") {
        // Hide the prompt text on the first tap
        if (script.promptText.enabled) {
            hidePromptText();
        }

        // Change the head binding (Zodiac mask)
        changeHeadBinding();
    }
});

// Initialize by showing the first mask and prompt text
changeHeadBinding();
